namespace EmailSender
{
    public class MyMailMessage
    {
        public string message { get; set; }
        public string subject { get; set; }
        public string senderEmail { get; set; }
        public string receiverEmail { get; set; }
    }
}